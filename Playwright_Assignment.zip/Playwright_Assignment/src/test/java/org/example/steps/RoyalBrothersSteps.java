package org.example.steps;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.factory.PlaywrightFactory;
import org.junit.Assert;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RoyalBrothersSteps {

    private Page page;

    private String city;
    private String pickupDateDisplay;
    private String dropoffDateDisplay;
    private String pickupTime;
    private String dropoffTime;

    private String pickupSubmit;
    private String dropoffSubmit;

    private final List<String> collectedBikes = new ArrayList<>();

    @Before
    public void setUp() {
        PlaywrightFactory.initBrowser();
        page = PlaywrightFactory.getPage();
    }

    @After
    public void tearDown() {
        PlaywrightFactory.closeBrowser();
    }

    @Given("I open Royal Brothers home page")
    public void i_open_royal_brothers_home_page() {
        page.navigate("https://www.royalbrothers.com/");
    }

    @When("I select city {string}")
    public void i_select_city(String city) {
        this.city = city;

        // Build correct city URL: /cochin/bike-rentals
        String cityWeblink = city.toLowerCase(Locale.ENGLISH).replace(" ", "");
        String cityUrl = "https://www.royalbrothers.com/" + cityWeblink + "/bike-rentals";

        page.navigate(cityUrl);
        page.waitForLoadState();
    }

    @And("I enter pickup date {string} and time {string}")
    public void i_enter_pickup_date_and_time(String pickupDate, String pickupTime) {
        this.pickupDateDisplay = pickupDate;
        this.pickupTime = pickupTime;

        DateTimeFormatter displayFormat = DateTimeFormatter.ofPattern("dd MMM, yyyy", Locale.ENGLISH);
        DateTimeFormatter submitFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        LocalDate date = LocalDate.parse(pickupDate, displayFormat);
        this.pickupSubmit = date.format(submitFormat);
    }

    @And("I enter dropoff date {string} and time {string}")
    public void i_enter_dropoff_date_and_time(String dropoffDate, String dropoffTime) {
        this.dropoffDateDisplay = dropoffDate;
        this.dropoffTime = dropoffTime;

        DateTimeFormatter displayFormat = DateTimeFormatter.ofPattern("dd MMM, yyyy", Locale.ENGLISH);
        DateTimeFormatter submitFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        LocalDate date = LocalDate.parse(dropoffDate, displayFormat);
        this.dropoffSubmit = date.format(submitFormat);
    }

    @And("I click on Search Bikes")
    public void i_click_on_search_bikes() {

        String cityWeblink = city.toLowerCase(Locale.ENGLISH).replace(" ", "");

        String url = "https://www.royalbrothers.com/search"
                + "?utf8=%E2%9C%93"
                + "&city=" + encode(cityWeblink)
                + "&current_service_type=bike-rentals"
                + "&pickup=" + encode(pickupDateDisplay)
                + "&pickup_submit=" + encode(pickupSubmit)
                + "&pickup_time=" + encode(pickupTime)
                + "&dropoff=" + encode(dropoffDateDisplay)
                + "&dropoff_submit=" + encode(dropoffSubmit)
                + "&dropoff_time=" + encode(dropoffTime);

        page.navigate(url);
        page.waitForLoadState();
    }

    @Then("I should see pickup date {string} and dropoff date {string} applied in search")
    public void i_should_see_pickup_and_dropoff_dates(String expectedPickup, String expectedDropoff) {
        String currentUrl = page.url();

        Assert.assertTrue("Pickup date missing from URL",
                currentUrl.contains("pickup=" + encode(expectedPickup)));

        Assert.assertTrue("Dropoff date missing from URL",
                currentUrl.contains("dropoff=" + encode(expectedDropoff)));
    }

    @And("I apply the location filter {string}")
    public void i_apply_the_location_filter(String location) {


        Locator searchBox = page.getByPlaceholder("Search Location");
        searchBox.fill(location);
        page.waitForTimeout(500);

        // Select from list
        Locator locationOption = page.locator(
                "//label[contains(normalize-space(), '" + location + "')]"
        );

        Assert.assertTrue("Location filter option not found: " + location,
                locationOption.count() > 0);

        locationOption.first().click();
        page.waitForTimeout(500);

        // Apply filter button
        Locator applyBtn = page.locator("//button[contains(., 'Apply filter')]");
        if (applyBtn.count() > 0) {
            applyBtn.first().click();
        }

        page.waitForTimeout(3000);
    }


    @Then("I collect bike model and availability for each card and verify location is {string}")
    public void i_collect_and_validate_cards(String expectedLocation) {

        page.waitForSelector("div.each_card_form h6.bike_name",
                new Page.WaitForSelectorOptions().setTimeout(15000));

        Locator cards = page.locator("div.each_card_form");
        int count = cards.count();

        Assert.assertTrue("No bike cards found", count > 0);

        for (int i = 0; i < count; i++) {

            Locator card = cards.nth(i);

            String bikeModel = card.locator("h6.bike_name").innerText().trim();

            // Selected location
            Locator selectedOption = card.locator("select.enhanced-select option[selected]");

            // Fix → Skip card if no selected option exists
            if (selectedOption.count() == 0) {
                System.out.println("Not Available " + i + " (" + bikeModel + ") - Not Available at the selected location");
                continue;
            }

            String availableAt = selectedOption.getAttribute("data-display-name");
            String address = selectedOption.getAttribute("data-address");

            System.out.println("Bike: " + bikeModel +
                    " | Main Location: " + availableAt +
                    " | Address: " + address);

            String expectedMain = expectedLocation.split("\\(")[0].trim();

            Assert.assertTrue(
                    "Location mismatch. Expected main: " + expectedMain + " but got: " + availableAt,
                    availableAt.contains(expectedMain)
            );
        }


    }

    @And("I print all bike model and available-at data to the console")
    public void i_print_data() {
        System.out.println("==== Bikes Collected ====");
        for (String entry : collectedBikes) {
            System.out.println(entry);
        }
        System.out.println("=========================");
    }

    private String encode(String val) {
        return URLEncoder.encode(val, StandardCharsets.UTF_8);
    }
}
