package org.example.factory;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class PlaywrightFactory {

    private static Playwright playwright;
    private static Browser browser;
    private static final ThreadLocal<Page> tlPage = new ThreadLocal<>();

    public static void initBrowser() {
        if (playwright == null) {
            playwright = Playwright.create();
            browser = playwright.chromium().launch(
                    new BrowserType.LaunchOptions()
                            .setHeadless(false)
            );
        }
        tlPage.set(browser.newPage());
    }

    public static Page getPage() {
        return tlPage.get();
    }

    public static void closeBrowser() {
        Page page = tlPage.get();
        if (page != null) {
            page.close();
            tlPage.remove();
        }
        if (browser != null) {
            browser.close();
            browser = null;
        }
        if (playwright != null) {
            playwright.close();
            playwright = null;
        }
    }
}
